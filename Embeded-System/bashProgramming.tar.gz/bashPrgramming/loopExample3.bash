###
 # @Author: Frank Linux
 # @Date: 2022-10-21 15:54:31
 # @LastEditors: Frank Linux
 # @LastEditTime: 2022-10-21 15:54:52
 # @FilePath: /EE/Embeded-System/bashPrgramming/loopExample3.bash
 # @Description: 
 # 
 # Copyright (c) 2022 by Frank Linux, All Rights Reserved. 
### 
#!/bin/bash

for user in vamei anna yutian
do 
    echo $user
done