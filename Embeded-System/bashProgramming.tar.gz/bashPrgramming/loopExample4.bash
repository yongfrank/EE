###
 # @Author: Frank Linux
 # @Date: 2022-10-21 15:57:44
 # @LastEditors: Frank Linux
 # @LastEditTime: 2022-10-21 15:57:50
 # @FilePath: /EE/Embeded-System/bashPrgramming/loopExample4.bash
 # @Description: 
 # 
 # Copyright (c) 2022 by Frank Linux, All Rights Reserved. 
### 

# get 1 3 5 7 9
seq 1 2 10