###
 # @Author: Frank Linux
 # @Date: 2022-10-20 16:57:15
 # @LastEditors: Frank Linux
 # @LastEditTime: 2022-10-20 16:59:40
 # @FilePath: /EE/Embeded-System/bashPrgramming/app.bash
 # @Description: 
 # 
 # Copyright (c) 2022 by Frank Linux, All Rights Reserved. 
### 
#!/bin/bash

source my_info.bash
my_info output.file

