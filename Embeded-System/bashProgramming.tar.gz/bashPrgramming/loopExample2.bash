###
 # @Author: Frank Linux
 # @Date: 2022-10-21 14:29:13
 # @LastEditors: Frank Linux
 # @LastEditTime: 2022-10-21 14:29:16
 # @FilePath: /EE/Embeded-System/bashPrgramming/loopExample2.bash
 # @Description: 
 # 
 # Copyright (c) 2022 by Frank Linux, All Rights Reserved. 
### 
#!/bin/bash

while true
do
    date
    sleep 1
done