###
 # @Author: Frank Linux
 # @Date: 2022-10-20 17:05:23
 # @LastEditors: Frank Linux
 # @LastEditTime: 2022-10-20 17:18:46
 # @FilePath: /EE/Embeded-System/bashPrgramming/logicalJudgeExample1.bash
 # @Description: 
 # 
 # Copyright (c) 2022 by Frank Linux, All Rights Reserved. 
### 

#!/bin/bash
test 3 -gt 2
echo $?
# True return 0; False return 1;
